package com.meer.model.service;

public interface WordService {
	public String readFortune(String userId);
	
	public String readSentence(String userId);
}
