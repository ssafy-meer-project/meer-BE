package com.meer.util;

import java.nio.charset.StandardCharsets;
import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {
	
	private final SecretKey secretKey;
	
	public JwtUtil(@Value("${jwt-key}") String key) {
		this.secretKey = Keys.hmacShaKeyFor(key.getBytes(StandardCharsets.UTF_8));		
	}

//	private String key = "meerProject_jwtkey_jaehyun_GreatJob";
//	private SecretKey secretKey = Keys.hmacShaKeyFor(key.getBytes(StandardCharsets.UTF_8));

	// 다양한 데이터를 Map으로 받아서 처리를 할수 도 있지만,
	// 심플하게 ID만 받아서 토큰을 만들어보자~~
	public String createToken(String userId) {
		return Jwts.builder()
				.header().add("typ", "JWT")
				.and()
				.claim("userId", userId)
				.expiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60))
				.signWith(secretKey)
				.compact();
	}

	public String validate(String token) {
		try {
			Claims claims = Jwts.parser().verifyWith(secretKey).build().parseSignedClaims(token).getBody();
			return claims.getSubject();
		} catch (Exception e) {
			return e.getMessage();
		}
	}

}
